# Erzählt von ihrem Vater

```json
{
  "date": "1985-08-12",
  "place": "Pizzaria in Vaasa",
  "synopsis": "Eddie erzählt Sini, wie ihr Vater trotz überragender Fähigkeiten im Schatten des Parteikarrieristen Radmer blieb.",
  "persons": [
    "Eddie",
    "Sini",
    "Eddies Vater",
    "Leonhard Radmer"
  ],
  "mood": "bitter yet intimate",
  "tense": "present, Eddies first-person perspective",
  "mode": "mainline",
  "feedback": {
    "anni": {
      "rating": ".....",
      "comments": ""
    },
    "lucia": {
      "rating": ".....",
      "comments": ""
    },
    "soek": {
      "rating": ".....",
      "comments": ""
    }
  },
  "todo": "Der Dialog der Mädchen ist noch zu schwach, zu redundant."
}
```

„Weißt du, mein Alter war im Studium der Allerbeste. Kernreaktortechnik, TU
Dresden -- der Typ konnte die Formeln aus dem Ärmel schütteln, wo die anderen
noch die Taschenrechner falsch rum hielten. Nur hat er sich halt nie für Politik
interessiert. Und da fängt die ganze Tragödie an.

Sein Kumpel damals hieß Leo. Eigentlich Leonhard Radmer, aber alle nannten ihn
Leo. Den hat mein Vater immer durchgezogen, durch jede verdammte Prüfung. Der
war nämlich so ein Parteihengst -- schon in der FDJ groß, dann früh in der SED.
Immer mit Fähnchen schwenken und Parolen brüllen, dafür aber in Mathe und Physik
auf dem Zahnfleisch.

Und was passiert? Nach dem Studium: Promotionsstelle für Leo. Für meinen Vater:
nichts. Als dann noch ein neuer Lehrstuhl ‚Reaktordynamik und
Sicherheitsforschung' aufgemacht wurde -- rat mal, wer da Professor wurde? Klar,
Radmer. Dr. Leonhard Radmer, frisch gebackener Parteisekretär.

Nur: der Typ hatte null Plan. Völlig überfordert mit der ganzen Nummer. Also hat
er meinen Vater als wissenschaftlichen Mitarbeiter geholt -- offiziell, um sich
glänzende Zuarbeit zu sichern. In echt war es eher so: Mein Vater macht die
ganze Arbeit, Radmer schnappt sich die Lorbeeren.

Das Verrückte: Der Lehrstuhl hat einen internationalen Ruf bekommen, sogar in
Frankreich werden die zitiert. Aber das liegt nicht an Radmer, sondern allein an
meinem Vater. Er ist das Hirn dahinter, aber im Rampenlicht steht immer der
falsche."

Sini schweigt kurz, zieht an einer losen blauen Haarsträhne. Dann sagt sie
leise, fast beiläufig: „Klingt wie'n schlechter Tausch. Talent gegen
Parteibuch."

Ich nicke. „Und das Bitterste: Ohne meinen Vater wäre dieser ganze Lehrstuhl
längst tot. Alle Welt lobt die ‚Arbeiten von Professor Radmer'. Aber eigentlich
ist es nur sein Deckmantel."

Sini lacht trocken, aber nicht böse. „Also dein Vater ist das Herz. Und Radmer
die Maske."\ Sie schaut mich schief an, als wollte sie prüfen, ob ich es auch so
empfinde. „Maske sind leichter zu zerreißen als Herzen, weißt du?"

Ich will noch etwas erwidern, vielleicht einen meiner altklugen Sprüche, aber da
steht plötzlich der Kellner vor uns. Groß, kantiges Gesicht, die Stirn schon
glänzend vom langen Abend. Er legt uns die Rechnung hin und sagt auf Finnisch
ein paar Worte, die eindeutig nach „Feierabend“ klingen.

„Rauswurf mit Stil“, murmelt Sini und schiebt ein paar Münzen auf den Teller.
Ich kicher, obwohl meine Gedanken noch bei meinem Vater hängen.

Wir ziehen die Jacken an, der Kellner löscht schon die Hälfte der Lichter. Als
wir auf die Straße treten, umfängt uns die kühle Nachtluft, so klar und still,
dass die letzten Worte von drinnen noch nachhallen.

Maske und Herz. Radmer und mein Vater. Und irgendwo dazwischen: ich.

Sini stupst mich an. „Na los, Herzmädchen. Heimweg, bevor er uns noch den Besen
hinterherwirft.“

Ich lache, diesmal frei, und wir gehen nebeneinander in die dunkle Straße
hinaus.
