# Vertauschte Jungs

```json
{
  "date": "1985-07-14",
  "daytime": "morning",
  "place": "Haukkajoki, etwa 40 % des Weges nach Vaasa",
  "persons": [
    "Eddie",
    "Peter",
    "Sabine",
    "Conny",
    "Matti"
  ],
  "synopsis": "Regenmorgen in der Hütte; Spaß, Neckereien und vertraute Stimmung geben Eddie erstmals das Gefühl dazuzugehören.",
  "mood": "warm, playful, safe",
  "tense": "present, Eddies first-person perspective",
  "mode": "mainline",
  "feedback": {
    "anni": {
      "rating": ".....",
      "comments": ""
    },
    "lucia": {
      "rating": ".....",
      "comments": ""
    },
    "soek": {
      "rating": ".....",
      "comments": ""
    }
  }
}
```

Es ist früh am Morgen, der Regen prasselt ununterbrochen auf das Dach der Hütte.
Ich bleibe noch ein Weilchen eingekuschelt im Schlafsack liegen und sehe Peter
zu, wie er draußen Wasser geholt hat und jetzt mit seinem Kocher hantiert. Ganz
ruhig, ganz konzentriert, als hätte er nie etwas anderes gemacht. Ich kann den
Blick nicht von seinen Augen lassen. Diese Farbe! So blau, dass man direkt
hineinfallen könnte wie in einen See.

„Na, erwischt?" Sabine grinst mich an, als hätte sie genau meinen Blick
eingefangen.

Ich zucke zusammen, eröte. „Ich? Nein… also… ich finde nur… …also echt, diese
unverschämt schönen Augen."

„Sag ich doch!" Sabine schubst Conny, die gerade verschlafen aus dem Schlafsack
kriecht. „Conny hat ihn mir weggeschnappt."

Conny kichert. „Genau. Aber nur weil ich bei diesem Muskelberg nicht punkten
konnte." Sie zeigt auf Matti, der in diesem Moment hereinkommt, pitschnass vom
Wasserholen.

Matti stellt die Kanister ab, stemmt die Arme in die Hüften und spannt wie zum
Spaß seine Oberarme an. „Na, neidisch?"

Ich lache laut los. „Also ich finde, Sabine hat wirklich einen guten Fang
gemacht. Wer braucht schon blaue Augen, wenn er ganze Fichtenstämme heben kann?"

Alle lachen, sogar Peter, der schmunzelnd den Kopf schüttelt. Weniger Muskeln,
aber diese Augen. Zum Glück muss ich mich nicht entscheiden.

Stattdessen lache ich mit, aus vollem Herzen. Zum ersten Mal seit Tagen fühle
ich mich nicht wie eine Fremde. Ich spüre, mein Geheimnis ist bei ihnen sicher.
Es ist, als würde von jedem von ihnen ein kleines Stück Wärme zu mir
herüberwandern.

Draußen rauscht der Regen weiter, dicker und dichter als gestern. Wir sehen uns
an -- keiner hat Lust, klatschnass zu paddeln oder durch den Wald zu stapfen.
„Wir bleiben noch eine Nacht", verkündet Conny. „Machen's uns gemütlich und
starten morgen mit doppelter Power."

Alle nicken, und ich ziehe mich wieder in meinen Schlafsack zurück. Ich höre den
Kocher fauchen, das Gelächter der anderen, und ich denke: *Wenn das schon
Freiheit ist -- wie wird dann erst mein richtiges Leben aussehen, wenn ich es
wirklich geschafft habe?*
