# Tampons

```json
{
  "date": "1985-07-17",
  "daytime": "evening, night, morning",
  "place": "Hütte bei den Paderbornern, Finnland",
  "persons": ["Eddie", "Sabine", "Conny", "Mattie", "Peter"],
  "synopsis": "Eddie bekommt von Sabine Tampons angeboten, probiert sie zum ersten Mal aus und entdeckt am sonnigen Morgen nach Regentagen beim gemeinsamen Baden im See eine neue Freiheit. Die Jungs Mattie und Peter zeigen auffälliges Interesse, was Eddie verlegen macht, aber insgeheim freut sie sich.",
  "mood": "intimate, cozy, liberating, shy but joyful",
  "tense": "present, Eddies first-person perspective",
  "mode": "mainline"
}
```

Am frühen Morgen, als die meisten in der Hütte noch schlafen und die Sonne
schräg durch die nassen Bäume fällt, dreht sich Sabine zu mir. Sie stützt den
Kopf auf die Hand, flüstert: „Sag mal, du hast gerade deine Tage, oder? Bist du
eigentlich noch … versorgt?“

Ich werde sofort rot. Für einen Augenblick fühle ich mich wie ein Kind, ertappt
mit Schokolade im Mund. Dann nicke ich, schüttle aber gleich wieder den Kopf.
„Nicht wirklich.“ Sabine grinst, aber nicht gemein, eher wie eine große
Schwester. „Hab fast nur Tampons. Willst du?“

Ich starre das Ding an, so winzig, fast lächerlich. Bei uns daheim sind die
Binden groß wie Sofakissen, und oft gab’s sie gar nicht. Ich stammle: „Noch nie
probiert. Keine Ahnung, wie das geht.“ Sabine erklärt leise, fast sachlich, wie
eine erwachsene Frau zu einer anderen: „Nicht verkrampfen. Drehen, nicht
drücken. Geht besser, wenn du entspannt bist. Probier’s gleich draußen. Und dann
Daumen hoch oder runter.“

Plötzlich halte ich ein Stück erwachsene Welt in der Hand. Mit der Packung fühle
ich mich nicht mehr wie ein Mädchen – sondern wie jemand, der ernst genommen
wird.

Ich schleiche hinaus, probiere es. Erst verkrampft, fast wie bei einer Mutprobe.
Dann klappt es. Ganz ungewohnt, fast so, als hätte ich etwas vergessen, was
eigentlich da sein müsste. Ich gehe ein paar Schritte – und es sitzt. Kein
Schmerz, nur neu. Ich lache leise, beinahe albern, und verstecke den kleinen
Faden wie einen geheimen Zaubertrick.

Zurück in die Hütte – Daumen hoch. Sabine grinst, klopft mir auf die Schulter.
Ein kleiner, wortloser Ritterschlag.

Dann bricht das Licht der Sonne durch, warm und hell. „Ab ins Wasser!“, ruft
Sabine, und plötzlich sind wir wieder wie Kinder im Ferienlager.

Matti und Peter reißen sofort die Klamotten runter. Ich hatte längst erklärt,
dass ich keine Badesachen habe – und nach einem Blick zwischen Sabine und Conny
ist klar: wir machen alle FKK.

Einen Herzschlag lang werde ich rot wie eine Zwölfjährige, die etwas Verbotenes
tut. Dann renne ich los, den Steg hinunter, springe ins Wasser. Es ist kalt, ich
japse, tauche, halte die Luft an wie früher beim Wetttauchen mit den Jungs aus
der Nachbarschaft. Fühle den kindlichen Übermut in mir.

Als ich auftauche, lache ich schrill und laut, plansche herum, spritze Conny
nass. Alles Leichtigkeit, alles Spiel. Doch dann bemerke ich, wie die Jungs mich
anschauen. Länger, intensiver. Sabine und Conny rufen neckisch: „He! Wir sind
auch noch da!“ Matti und Peter drehen sich weg, zu schnell, zu schuldbewusst.
Ich werde rot, diesmal anders. Nicht wie ein Kind, sondern wie eine Frau, die
plötzlich spürt, was Blicke bedeuten können.

Ich erwische Peters Augen – so blau, dass mir schwindelig wird. Gleichzeitig
glänzt Mattis Körper im Sonnenlicht, fast wie aus einer Reklame. Ich erschrecke
über das warme Ziehen in meinem Bauch, tauche sofort ab, verstecke mein Gesicht
unter Wasser. Und kichere dort unten – kindlich, albern, unsicher.

Später am Ufer reibe ich mir das Wasser von den Armen. Reiß dich zusammen, denke
ich streng, wie eine Erwachsene. Das ist nur ein Badetag. Doch während ich das
Handtuch um mich schlage, spüre ich dieses Leuchten in mir, das nicht von der
Sonne kommt. Vielleicht bin ich nicht mehr nur das unsichtbare Mathe-Mädchen.
Vielleicht fängt hier gerade etwas Neues an.
