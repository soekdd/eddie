# Schule beginnt

```json
{
  "title": "Schule beginnt",
  "date": "1985-09-01",
  "daytime": "morning, afternoon, evening",
  "place": "Vaasa, Finnland",
  "persons": ["Eddie", "Sini"],
  "synopsis": "Am 1. September wird Eddie bewusst, dass in der DDR die Schule wieder beginnt. Beim Frühstück erzählt sie Sini davon, die den FDJ-Gruß auf komische Weise nachmacht. Eddie lacht, wird aber auch schwermütig, weil sie das Lernen vermisst. Statt Sini zum Terminal zu begleiten, geht sie in die Uni-Bibliothek von Vaasa, liest besessen ein englisches Buch über Technische Mechanik und macht am Abend einen Witz, um die Schwere zu vertreiben. Sini erwähnt beiläufig, dass sie einmal Biologie studiert hat, spricht darüber aber nicht weiter.",
  "mood": "light, humorous, tinged with hidden melancholy",
  "tense": "present, Eddies first-person perspective",
  "mode": "mainline"
}
```

Es ist der erste September. Wir frühstücken in der kleinen Küche, das Fenster
steht offen, irgendwo draußen bellen Hunde. Sini trinkt ihren Kaffee in großen
Schlucken, ich knabbere an einem Brötchen. Da sage ich plötzlich: „Heute geht
bei uns die Schule wieder los. In Dresden stehen sie jetzt alle im FDJ-Hemd
stramm, die Fahnen knattern, und die Lehrer predigen, wie wichtig unser Beitrag
zum Sozialismus ist.“

Sini schaut kurz, dann springt sie auf, schnellt in Habachtstellung und ruft
lachend: „Für Frieden und Sozialismus – seid bereit!“

Sie reißt die Hand hoch, aber so verkrampft, dass es mich fast vom Hocker haut.
Ich pruste los, zwischen zwei Lachern keuche ich: „Sini, um Himmels willen –
diese Handbewegung darfst Du nie machen! Das ist streng verboten. Geht gar
nicht.“

Sie erstarrt, wird knallrot. „Was? Echt jetzt?“ ruft sie, „ich dachte, das wär
nur so ein… keine Ahnung, DDR-Ding?“

Ich lache noch immer Tränen. „Nein! Ganz falsches Land, ganz falsche Zeit, ganz
falsche Geste!“

Für einen Moment wirkt sie richtig betreten, dann verzieht sie das Gesicht,
macht eine völlig übertriebene Hampelmannbewegung daraus und wir brechen beide
endgültig zusammen vor Lachen, so sehr, dass mir Tränen die Wangen
hinunterlaufen.

Aber als sie wieder sitzt, bleibt bei mir ein Rest von Schwere. Lernen – das war
immer meins. Ich mochte es, Neues aufzunehmen, Aufgaben zu lösen, zu verstehen.
Und jetzt? Jetzt hocke ich hier mit Sini herum, als hätte ich endlos Ferien.
Irgendwas in mir schreit: *Du verlierst Zeit.*

Als wir das Geschirr abspülen, sage ich beiläufig, dass ich sie heute nicht bis
zum Terminal begleite. Sie mustert mich, dann nickt sie nur und erklärt mir, wie
ich zur Uni-Bibliothek finde.

Am Nachmittag sitze ich dort zwischen hohen Regalen. Die meisten Bücher sind auf
Finnisch oder Englisch. Ich greife nach einem schweren Band – „Technical
Mechanics“ – und stürze mich hinein, als müsste ich es mir selbst beweisen.
Seite um Seite, Formeln, Zeichnungen. Mein Kopf hämmert, aber ich höre nicht
auf. Es ist fast wie ein Rausch, endlich wieder in Arbeit zu versinken.

Abends treffe ich Sini wieder. Sie fragt, wie es war, ich erzähle, wie besessen
ich gelesen habe. Da sagt sie leise: „Du weißt, ich hab auch mal Biologie
studiert.“ Einen Moment denke ich, sie will mir endlich mehr erzählen, doch dann
winkt sie ab, als hätte sie den Faden verloren.

Um die Schwere zu verscheuchen, mache ich einen Witz: „Weißt du, was ich heute
gelernt habe? Wenn eine Kraft in Newton wirkt und niemand da ist, sie zu messen,
dann hat sie trotzdem Arbeit verrichtet.“ Ich grinse. Sini lacht auf, schüttelt
den Kopf. „Du und deine Physik. Irgendwann muss man mal ein Wort für Leute wie
dich erfinden.“
