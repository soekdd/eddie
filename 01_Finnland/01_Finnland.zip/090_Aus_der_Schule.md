# Aus der Schule

```json
{
  "date": "1985-07-05",
  "daytime": "noon",
  "place": "Gymnasium Joutsa",
  "persons": [
    "Eddie",
    "Mielke",
    "Herr Fischer",
    "Mongolen",
    "Bulgaren",
    "Schwede",
    "DDR-Gruppe"
  ],
  "synopsis": "Eddie entkommt im Gedränge nach den Prüfungen knapp an Mielke vorbei und flieht ins Freie.",
  "mood": "tense, breathless, fleeting relief",
  "tense": "present, Eddies first-person perspective",
  "mode": "mainline",
  "feedback": {
    "anni": {
      "rating": ".....",
      "comments": ""
    },
    "lucia": {
      "rating": ".....",
      "comments": ""
    },
    "soek": {
      "rating": ".....",
      "comments": ""
    }
  }
}
```

Ich reiße die Kabinentür auf. Mein Herz hämmert so laut, ich schwöre, jeder in
der Toilette muss es hören. Aber die Jungs? Keine Reaktion. Die labern weiter,
völlig in ihre Gespräche vertieft. Beim Händewaschen schnappe ich einen Blick in
den Spiegel: Ein Fremder glotzt mich an – kantiges Gesicht, verwuschelt,
schwarze Haare, die im Neonlicht stumpf glänzen. Lederbergschuhe unten drunter.
Sieht aus, als wär das alles schon immer meins gewesen.

Dann raus auf den Gang – und zack, der Geräuschpegel knallt mir wie ’ne Welle
ins Gesicht. Stimmen aus allen Richtungen: Finnisch, Russisch, Englisch, ein
paar Brocken Chinesisch. Die Kids sind aufgedreht, Arme fuchteln durch die Luft,
sie reden über die Aufgaben. *„Die zweite war unmöglich!“* höre ich auf
Englisch. Irgendwo nervöses Lachen.

Kopf runter, rein in die Menge. Die schwarzen Haare stinken noch nach
Schuhcreme. Mein Tarnanzug – und gleichzeitig meine größte Schwachstelle.

Und dann seh ich ihn. *Mielke.* Grauer Anzug, schmale Lippen, Augen wie spitze
Nadeln. Steht da am Eingang wie ’n Scanner, Arme verschränkt. Er weiß, warum er
da ist – und ich auch: Keiner aus der DDR geht hier allein irgendwohin.

Neben ihm Herr Fischer. Nicht so scharf, eher müde Augen. Er redet mit ’nem
finnischen Lehrer, nickt, guckt rum – und dann bleibt sein Blick an mir hängen.
Zu lange. Er hat mich erkannt. Trotz Haaren, trotz Jacke. Mist.

Jetzt oder nie. Wenn Mielke mich sieht, ist Schluss.

Die Menge schiebt Richtung Ausgang. Plötzlich tritt Fischer einen Schritt vor,
direkt in Mielkes Bahn. „Einen Moment, ich muss Ihnen noch was zeigen …“ höre
ich. Mielke dreht sich genervt zu ihm. Mein Schlupfloch!

Ich husche los, vorbei an einer Gruppe Mongolen, dränge mich zwischen zwei
Bulgaren. Der Flur ist voll, alles wogt, mein Herz rast. Immer wieder ein
schneller Blick über die Schulter – Mielke checkt mich nicht. Noch nicht.

An der Tür nach draußen knallt mir einer entgegen, ich stolpere, fange mich an
der Wand. Ein Schwede mit Sommersprossen murmelt eine Entschuldigung. Ich nicke
nur, weiter, weiter!

Draußen grelles Licht. Da vorne der Bus. Die Jungs aus unserer Gruppe klettern
schon rein. Wenn ich geradeaus gehe, bin ich geliefert.

Also links abbiegen, so unauffällig wie möglich. Am Heck vorbei. Hinter mir
Stimmen – eine davon klingt nach Mielke. Ich lege einen Zahn zu.

Und dann – da! Kleine Baumgruppe, nur ein paar Meter. Ich tauche rein, Zweige
kratzen an meiner Jacke, Blätter rauschen und fressen die Stimmen.

Ich presse mich an eine Birke. Atem brennt. Ich bin nicht frei – aber ich bin
draußen.
