# Der Wettkampf

```json
{
  "date": "1985-07-05",
  "daytime": "morning",
  "place": "Klassenraum Gymnasium Joutsa",
  "persons": [
    "Eddie",
    "viele andere Kinder und Betreuer"
  ],
  "synopsis": "Eddie kann sich nicht auf die Aufgaben konzentrieren. Sie ist die erste, den den Raum Richtung Toilette verläßt",
  "mood": "tense relief, fear",
  "tense": "present, Eddies first-person perspective",
  "mode": "mainline",
  "illustrations": [
    "FIN_Jotsenlampi_Wettkampf.png"
  ],
  "feedback": {
    "anni": {
      "rating": ".....",
      "comments": ""
    },
    "lucia": {
      "rating": ".....",
      "comments": ""
    },
    "soek": {
      "rating": ".....",
      "comments": ""
    }
  }
}
```

Der Stift hängt in meiner Hand, das Blatt liegt vor mir – und die Zahlen darauf
tanzen wie kleine Spione, die mich auslachen. Ich blinzle, lese die drei
Aufgaben noch mal, noch mal… nix. Gar nix. Gestern noch dachte ich: Ha, ich
rechne die hier alle an die Wand, und wenn sie dann meinen Namen bei der
Siegerehrung aufrufen – bin ich weg. Kleiner Triumph. Schock für die Bonzen.
Aber jetzt? Ich krieg nicht mal den Anfang hin.

Die Uhr tickt über der Tür, viel zu laut, viel zu lahm, viel zu schnell. Alles
gleichzeitig. Ich weiß nicht mal mehr, wovor ich mehr Schiss hab – dass mir die
Zeit durch die Finger rinnt oder dass sie einfach nie vergeht. Jeder Strich von
den anderen klingt wie Hohn in meinen Ohren. Ich starre die Aufgabe an, als
könnte sie sich selbst in Luft auflösen, wenn ich nur lang genug draufgucke.
Stattdessen schmiert mein Kopf ab.

Pochen im Schädel. Klar, nach der Nacht ohne Schlaf. Nur rumgewälzt, nur
gegrübelt. Die Angst hängt mir im Nacken wie ’ne kalte Hand. Ich will raus. Raus
hier, raus aus diesem Raum, raus aus allem.

Ich schiel nach links, nach rechts. Alle im Tunnel, Stifte kratzen, Radiergummis
rubbeln, manche knabbern nervös dran rum. Nur ich – ein Fake. Tu so, als ob. Ich
schieb das Blatt hin und her, als würde die Perspektive helfen. Tut sie nicht.
Nur noch mehr Leere.

Und dann halt ich’s nicht mehr aus. Stift weg. Ich versuch so zu gucken, als wär
ich fertig. Aber ich weiß: Ich bin die Erste. Viel zu früh. Ich pack meine
jämmerlichen Krakel in die offizielle IMO-Mappe. Mein Stuhl quietscht mies, als
ich hochgeh. Ein paar Köpfe drehen sich. Ich spür die Blicke. Ich lächle nicht.
Sag nix. Tasche geschnappt. Tür im Visier.

Zum Betreuer flüster ich: „Bin fertig, muss mal schnell auf Toilette.“ Und zu
mir selbst: Nur raus hier. Niemand darf merken, dass du wegläufst. Der Typ guckt
schräg, nickt dann.

Tür zu. Bäm. Ich steh im langen, hellen Flur. Leer, zum Glück. Endlich raus aus
der stickigen Hölle. Meine Schuhe quietschen viel zu laut auf dem Linoleum. Ich
geh schneller, als hätte ich wirklich dringend… na ja.

Die Tür mit dem Mädchenschild kommt. Ich streif sie nur mit’m Blick – und geh
weiter. Noch zwei Türen. Da: Jungen.

Herz hämmert bis in den Hals. Wenn mich hier einer erwischt… Aber niemand da.
Ich stoße die Tür auf. Scharfer Putzmittel-Geruch haut mir entgegen. Urinale
hängen an der Wand wie offene Mäuler. Keiner drin. Perfekt.

Im Vorbeigehen ein Blick in die Spiegel. Dieses Mädel da starrt mich an:
zerzaust, Augenringe, ein Gesicht, das mich selbst erschreckt. Aber egal –
dieses Mädel verschwindet sowieso gleich.

Ich geh in die letzte Kabine, Schloss zu, Rücken gegen die Tür. Endlich Luft.
